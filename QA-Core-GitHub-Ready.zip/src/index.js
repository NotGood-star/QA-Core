import "dotenv/config";
import {
  Client,
  GatewayIntentBits,
  Events,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
  PermissionsBitField,
  EmbedBuilder
} from "discord.js";

import { CONFIG, COLOR } from "./config.js";
import {
  createTest, getTest, getJoinedCount, joinTest, listTesters,
  setTestMessage
} from "./db.js";
import { hostPanelEmbed, hostPanelRow, testEmbed, testButtons } from "./embeds.js";

const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMembers]
});

function hasRole(interaction, roleId) {
  return interaction.member?.roles?.cache?.has(roleId);
}

function modalInput(id, label, placeholder, style = TextInputStyle.Short, required = true) {
  return new ActionRowBuilder().addComponents(
    new TextInputBuilder()
      .setCustomId(id)
      .setLabel(label)
      .setPlaceholder(placeholder)
      .setStyle(style)
      .setRequired(required)
  );
}

client.once(Events.ClientReady, c => {
  console.log(`QA Central online as ${c.user.tag}`);
});

client.on(Events.InteractionCreate, async interaction => {
  try {
    if (interaction.isChatInputCommand()) {
      if (interaction.commandName !== "qa") return;

      const sub = interaction.options.getSubcommand();

      if (sub === "setup") {
        if (!interaction.memberPermissions?.has(PermissionsBitField.Flags.ManageGuild)) {
          return interaction.reply({ content: "❌ You need **Manage Server** to use this.", ephemeral: true });
        }
        if (interaction.channelId !== CONFIG.channels.host) {
          return interaction.reply({ content: `⚠️ Use this command in <#${CONFIG.channels.host}>.`, ephemeral: true });
        }
        return interaction.reply({ embeds: [hostPanelEmbed()], components: [hostPanelRow()] });
      }

      if (sub === "test") {
        const id = interaction.options.getInteger("id", true);
        const test = getTest(id);
        if (!test) return interaction.reply({ content: "❌ Test not found.", ephemeral: true });
        const joined = getJoinedCount(id);
        return interaction.reply({ embeds: [testEmbed(test, joined)], components: [testButtons(test, joined)] });
      }

      if (sub === "close") {
        if (!interaction.memberPermissions?.has(PermissionsBitField.Flags.ManageGuild)) {
          return interaction.reply({ content: "❌ You need **Manage Server** to use this.", ephemeral: true });
        }
        const id = interaction.options.getInteger("id", true);
        const test = getTest(id);
        if (!test) return interaction.reply({ content: "❌ Test not found.", ephemeral: true });
        // Closing is implemented by updating the DB status in a later module/version.
        return interaction.reply({ content: `ℹ️ Test #${id} exists. Full close/status workflow is next in V2.`, ephemeral: true });
      }
    }

    if (interaction.isButton() && interaction.customId === "qa_host_start") {
      if (!hasRole(interaction, CONFIG.roles.developer)) {
        return interaction.reply({
          content: `${CONFIG.emojis.qa_cross} You need the **Developer** role to host a test.`,
          ephemeral: true
        });
      }

      const modal = new ModalBuilder()
        .setCustomId("qa_host_modal")
        .setTitle("QA Central • Host a Test");

      modal.addComponents(
        modalInput("game_name", "Game Name", "Anime Zenith"),
        modalInput("game_link", "Game Link", "https://www.roblox.com/games/..."),
        modalInput("max_testers", "Max Testers", "2"),
        modalInput("schedule", "Start | End Time", "Today 7:00 PM | 8:00 PM"),
        modalInput("description", "Description / Requirements", "Find bugs, play 10 minutes, give feedback.", TextInputStyle.Paragraph)
      );

      return interaction.showModal(modal);
    }

    if (interaction.isModalSubmit() && interaction.customId === "qa_host_modal") {
      const gameName = interaction.fields.getTextInputValue("game_name").trim();
      const gameLink = interaction.fields.getTextInputValue("game_link").trim();
      const maxTesters = Number(interaction.fields.getTextInputValue("max_testers").trim());
      const schedule = interaction.fields.getTextInputValue("schedule").trim();
      const description = interaction.fields.getTextInputValue("description").trim();

      if (!/^https?:\/\/(www\.)?roblox\.com\/.+/i.test(gameLink)) {
        return interaction.reply({ content: "❌ Please provide a valid Roblox game URL.", ephemeral: true });
      }
      if (!Number.isInteger(maxTesters) || maxTesters < 1 || maxTesters > 100) {
        return interaction.reply({ content: "❌ Max testers must be a whole number from 1 to 100.", ephemeral: true });
      }

      const typeMenu = new StringSelectMenuBuilder()
        .setCustomId(`qa_type:${encodeURIComponent(JSON.stringify({
          gameName, gameLink, maxTesters, schedule, description
        }))}`)
        .setPlaceholder("Choose the test type")
        .addOptions(
          new StringSelectMenuOptionBuilder()
            .setLabel("Paid Test")
            .setDescription("Offer a reward to testers")
            .setValue("paid")
            .setEmoji(CONFIG.emojis.qa_paid.match(/:([^:]+):/)?.[1] || "💰"),
          new StringSelectMenuOptionBuilder()
            .setLabel("Volunteer Test")
            .setDescription("Free community testing")
            .setValue("volunteer")
            .setEmoji("🆓")
        );

      return interaction.reply({
        content: `${CONFIG.emojis.qa_test} **One more step:** choose the test type.`,
        components: [new ActionRowBuilder().addComponents(typeMenu)],
        ephemeral: true
      });
    }

    if (interaction.isStringSelectMenu() && interaction.customId.startsWith("qa_type:")) {
      if (!hasRole(interaction, CONFIG.roles.developer)) {
        return interaction.update({ content: "❌ Developer role required.", components: [] });
      }

      const payload = JSON.parse(decodeURIComponent(interaction.customId.slice("qa_type:".length)));
      const type = interaction.values[0];

      if (type === "paid") {
        const modal = new ModalBuilder().setCustomId(`qa_reward:${encodeURIComponent(JSON.stringify(payload))}`).setTitle("QA Central • Reward");
        modal.addComponents(
          modalInput("reward", "Reward Per Tester", "20 Robux")
        );
        return interaction.showModal(modal);
      }

      const testId = createTest({
        guild_id: interaction.guildId,
        host_id: interaction.user.id,
        game_name: payload.gameName,
        game_link: payload.gameLink,
        test_type: "volunteer",
        max_testers: payload.maxTesters,
        reward: null,
        description: payload.description,
        start_time: payload.schedule.split("|")[0]?.trim() || payload.schedule,
        end_time: payload.schedule.split("|").slice(1).join("|").trim() || "Not specified",
        created_at: new Date().toISOString()
      });

      const test = getTest(testId);
      const channel = await interaction.guild.channels.fetch(CONFIG.channels.volunteer);
      const message = await channel.send({
        embeds: [testEmbed(test, 0)],
        components: [testButtons(test, 0)]
      });
      setTestMessage(testId, channel.id, message.id);

      return interaction.update({
        content: `${CONFIG.emojis.qa_check} Volunteer test **#${testId}** has been posted in <#${CONFIG.channels.volunteer}>.`,
        components: []
      });
    }

    if (interaction.isModalSubmit() && interaction.customId.startsWith("qa_reward:")) {
      const payload = JSON.parse(decodeURIComponent(interaction.customId.slice("qa_reward:".length)));
      const reward = interaction.fields.getTextInputValue("reward").trim();

      const testId = createTest({
        guild_id: interaction.guildId,
        host_id: interaction.user.id,
        game_name: payload.gameName,
        game_link: payload.gameLink,
        test_type: "paid",
        max_testers: payload.maxTesters,
        reward,
        description: payload.description,
        start_time: payload.schedule.split("|")[0]?.trim() || payload.schedule,
        end_time: payload.schedule.split("|").slice(1).join("|").trim() || "Not specified",
        created_at: new Date().toISOString()
      });

      const test = getTest(testId);
      const channel = await interaction.guild.channels.fetch(CONFIG.channels.paid);
      const message = await channel.send({
        embeds: [testEmbed(test, 0)],
        components: [testButtons(test, 0)]
      });
      setTestMessage(testId, channel.id, message.id);

      return interaction.reply({
        content: `${CONFIG.emojis.qa_check} Paid test **#${testId}** has been posted in <#${CONFIG.channels.paid}>.`,
        ephemeral: true
      });
    }

    if (interaction.isButton() && interaction.customId.startsWith("qa_join:")) {
      if (!hasRole(interaction, CONFIG.roles.tester)) {
        return interaction.reply({ content: `${CONFIG.emojis.qa_cross} You need the **Tester** role to apply.`, ephemeral: true });
      }

      const id = Number(interaction.customId.split(":")[1]);
      const result = joinTest(id, interaction.user.id);

      if (!result.ok) {
        const messages = {
          not_found: "❌ Test not found.",
          closed: "🔒 This test is closed.",
          already_joined: "⚠️ You already joined this test.",
          full: "🔒 This test is full."
        };
        return interaction.reply({ content: messages[result.reason] || "❌ Could not join.", ephemeral: true });
      }

      const test = getTest(id);
      const joined = getJoinedCount(id);

      if (interaction.message?.editable) {
        await interaction.message.edit({
          embeds: [testEmbed(test, joined)],
          components: [testButtons(test, joined)]
        }).catch(() => {});
      }

      return interaction.reply({
        content: `${CONFIG.emojis.qa_check} You're registered for **${test.game_name}**!\n${CONFIG.emojis.qa_roblox} ${test.game_link}`,
        ephemeral: true
      });
    }

    if (interaction.isButton() && interaction.customId.startsWith("qa_testers:")) {
      const id = Number(interaction.customId.split(":")[1]);
      const test = getTest(id);
      if (!test) return interaction.reply({ content: "❌ Test not found.", ephemeral: true });

      const users = listTesters(id);
      const text = users.length
        ? users.map((x, i) => `**${i + 1}.** <@${x.user_id}>`).join("\n")
        : "No testers yet.";

      return interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(COLOR)
            .setTitle(`${CONFIG.emojis.qa_tester} Testers • #${id}`)
            .setDescription(text)
            .setFooter({ text: `${users.length}/${test.max_testers} slots filled` })
        ],
        ephemeral: true
      });
    }
  } catch (error) {
    console.error(error);
    if (!interaction.replied && !interaction.deferred) {
      await interaction.reply({ content: "❌ Something went wrong. Check the bot console.", ephemeral: true }).catch(() => {});
    }
  }
});

client.login(process.env.DISCORD_TOKEN);
