import { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } from "discord.js";
import { CONFIG, COLOR } from "./config.js";

const e = CONFIG.emojis;

export function hostPanelEmbed() {
  return new EmbedBuilder()
    .setColor(COLOR)
    .setTitle(`${e.qa_logo} QA CORNER — HOST A TEST`)
    .setDescription(
      `${e.qa_developer} **Are you a Roblox developer looking for testers?**\n\n` +
      `Create a **Paid** or **Volunteer** QA test and connect with Roblox players who want to help improve games.\n\n` +
      `${e.qa_test} Click the button below to start your test request.`
    )
    .addFields(
      { name: `${e.qa_paid} Paid Tests`, value: "Offer a reward to testers.", inline: true },
      { name: `${e.qa_free} Volunteer Tests`, value: "Get free community testing.", inline: true },
      { name: `${e.qa_feedback} QA Feedback`, value: "Collect useful game feedback and bug reports.", inline: false }
    )
    .setFooter({ text: "QA Central • Test. Report. Improve." })
    .setTimestamp();
}

export function hostPanelRow() {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId("qa_host_start")
      .setLabel("Host a Test")
      .setEmoji("🎫")
      .setStyle(ButtonStyle.Primary)
  );
}

export function testEmbed(test, joined) {
  const typeLine = test.test_type === "paid"
    ? `${e.qa_paid} Paid`
    : `${e.qa_free} Volunteer`;

  const rewardLine = test.test_type === "paid"
    ? `${e.qa_robux} ${test.reward || "Reward not specified"}`
    : `${e.qa_free} Free`;

  return new EmbedBuilder()
    .setColor(COLOR)
    .setTitle(`${e.qa_upcoming} ${test.game_name}`)
    .setURL(test.game_link)
    .setDescription(test.description)
    .addFields(
      { name: `${e.qa_developer} Developer`, value: `<@${test.host_id}>`, inline: true },
      { name: `${e.qa_test} Type`, value: typeLine, inline: true },
      { name: `${e.qa_reward} Reward`, value: rewardLine, inline: true },
      { name: `${e.qa_upcoslots} Max Testers`, value: String(test.max_testers), inline: true },
      { name: `${e.qa_slots} Joined`, value: `${joined}/${test.max_testers}`, inline: true },
      { name: `${e.qa_calendar} Schedule`, value: `**Start:** ${test.start_time}\n**End:** ${test.end_time}`, inline: false },
      { name: `${e.qa_roblox} Game`, value: `[Open Roblox Game](${test.game_link})`, inline: false },
      { name: "🎮 Platforms", value: `${e.qa_pc} PC  •  ${e.qa_mobile} Mobile  •  ${e.qa_console} Console`, inline: false }
    )
    .setFooter({ text: `QA Central • Test #${test.id}` })
    .setTimestamp();
}

export function testButtons(test, joined) {
  const full = joined >= test.max_testers;
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`qa_join:${test.id}`)
      .setLabel(full ? "Test Full" : "Apply as Tester")
      .setEmoji(full ? "🔒" : "📝")
      .setStyle(full ? ButtonStyle.Secondary : ButtonStyle.Success)
      .setDisabled(full),
    new ButtonBuilder()
      .setCustomId(`qa_testers:${test.id}`)
      .setLabel("View Testers")
      .setEmoji("👥")
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setLabel("Open Game")
      .setURL(test.game_link)
      .setEmoji("🎮")
      .setStyle(ButtonStyle.Link)
  );
}
