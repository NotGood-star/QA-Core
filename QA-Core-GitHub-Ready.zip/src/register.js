import "dotenv/config";
import { REST, Routes, SlashCommandBuilder } from "discord.js";

const commands = [
  new SlashCommandBuilder()
    .setName("qa")
    .setDescription("QA Central controls")
    .addSubcommand(s => s.setName("setup").setDescription("Post the Host a Test panel"))
    .addSubcommand(s => s.setName("test").setDescription("Show a test by ID")
      .addIntegerOption(o => o.setName("id").setDescription("Test ID").setRequired(true)))
    .addSubcommand(s => s.setName("close").setDescription("Close a test")
      .addIntegerOption(o => o.setName("id").setDescription("Test ID").setRequired(true)))
].map(c => c.toJSON());

const rest = new REST({ version: "10" }).setToken(process.env.DISCORD_TOKEN);

await rest.put(
  Routes.applicationGuildCommands(process.env.CLIENT_ID, process.env.GUILD_ID),
  { body: commands }
);

console.log("Registered QA Central slash commands.");
