# QA Central Discord Bot — V1

A Discord bot for connecting Roblox developers with game testers through Paid and Volunteer QA tests.

## Included in V1

- Developer-only Host a Test button
- Modal for:
  - Game Name
  - Game Link
  - Max Testers
  - Start | End Time
  - Description / Requirements
- Paid / Volunteer test type selection
- Paid reward modal
- Automatic posting to the configured Paid/Volunteer channel
- Tester-role verification
- Apply as Tester button
- Tester capacity tracking
- View Testers button
- SQLite persistence
- Slash commands:
  - `/qa setup`
  - `/qa test <id>`
  - `/qa close <id>` (placeholder for V2)
- Your supplied custom emoji IDs are already configured

## Setup

1. Install Node.js 24.17+.
2. Copy `.env.example` to `.env`.
3. Put your Discord bot token, application/client ID, and server/guild ID in `.env`.
4. Install packages:

```bash
npm install
```

5. Register the commands:

```bash
npm run register
```

6. Start:

```bash
npm start
```

## Bot permissions

Give the bot enough permissions to:
- View Channels
- Send Messages
- Embed Links
- Read Message History
- Use Application Commands

The bot also needs access to the four configured channels.

## Important

Never put your Discord bot token into public GitHub repositories or send it to other people. If a token is exposed, regenerate it in the Discord Developer Portal.
